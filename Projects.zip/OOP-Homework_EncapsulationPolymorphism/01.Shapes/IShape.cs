﻿namespace _01.Shapes
{
    public interface IShape
    {
        double CalculateArea();

        double CalculatePerimeter();
    }
}
