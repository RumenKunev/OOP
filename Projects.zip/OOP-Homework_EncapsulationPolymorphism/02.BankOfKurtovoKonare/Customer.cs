﻿public enum CustomerType
{
    Person,
    Company
} 
