﻿public interface ISound
{
    void ProduceSound();
}
