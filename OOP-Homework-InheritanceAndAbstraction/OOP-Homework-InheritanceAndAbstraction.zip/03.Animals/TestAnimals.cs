﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _03.Animals
{
    class TestAnimals
    {
        static void Main(string[] args)
        {
            Dog[] dogs = new Dog[]
            {
                new Dog("Balkan", 4, Gender.Male),
                new Dog("Majlo", 3, Gender.Male),
                new Dog("Strashimirka", 7, Gender.Female)
            };

            Frog[] frogs = new Frog[]
            {
                new Frog("Kermit", 2, Gender.Male),
                new Frog("Zhabcho", 4, Gender.Male)
            };

            Kitten[] kittens = new Kitten[]
            {
                new Kitten("Kat", 6),
                new Kitten("Sweety", 0)
            };

            Tomcat[] tomcats = new Tomcat[]
            {
                new Tomcat("Lucky", 7),
                new Tomcat("Tom", 6)
            };

            var dogsAverageAge = dogs.Average(dog => dog.Age);
            Console.WriteLine(dogsAverageAge);
        }
    }
}
