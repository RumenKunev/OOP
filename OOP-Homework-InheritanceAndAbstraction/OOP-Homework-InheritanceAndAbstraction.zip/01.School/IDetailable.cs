﻿public interface IDetailable
{
    string Details { get; set; }
}

